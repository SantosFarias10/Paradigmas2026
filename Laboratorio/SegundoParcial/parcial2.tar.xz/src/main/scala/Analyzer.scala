/**
 * Responsable de detectar entidades nombradas en texto libre y
 * producir estadísticas sobre ellas.
 */
object Analyzer {

  /**
   * Detecta las entidades del diccionario que aparecen en el texto dado.
   *
   * @param text       texto a analizar (ej: título o cuerpo de un post)
   * @param dictionary lista de entidades conocidas (cargadas desde los diccionarios)
   * @return lista de entidades cuyo texto aparece en el texto analizado
   */
  def detectEntities(text: String, dictionary: List[NamedEntity]): List[NamedEntity] = {
    val dictionaryFiltered: List[NamedEntity] = dictionary.filter { entity => 
      val result: Boolean = entity.matches(text)

      result
    }

    return dictionaryFiltered
  }

  /**
   * Cuenta cuántas entidades de cada tipo fueron detectadas.
   *
   * @param entities lista de entidades detectadas
   * @return mapa de entityType → cantidad de apariciones
   */
  def countByType(entities: List[NamedEntity]): Map[String, Int] = {
    entities.groupBy(_.entityType).view.mapValues(_.size).toMap
  }

  def detectRelevant(text: String, dictionary: List[NamedEntity]): List[NamedEntity] = {
    def dictionaryFiltered: List[NamedEntity] = dictionary.filter { entity =>
      val result: Boolean = entity.matches(text) && entity.isRelevant

      result
    }

    return dictionaryFiltered
  }
}
