import scala.util.matching.Regex
import java.util.regex.Pattern

/**
 * Clase base abstracta para todas las entidades nombradas.
 *
 * Una entidad nombrada es una expresión del texto que refiere a un objeto
 * del mundo real (persona, lugar, organización, tecnología, etc.).
 *
 * @param text el texto tal como aparece en el corpus
 */
abstract class NamedEntity(val text: String) {

  /**
   * Retorna el tipo de la entidad como String.
   */
  def entityType: String

  /**
   * Retorna una línea de descripción de la entidad para el informe.
   */
  def describe: String = s"[$entityType] $text"

  /*
   * 
  */
  def matches(text: String): Boolean = {
    val textRegex: String = Pattern.quote(text)
    
    val regex: Regex = s"(?i)\\b${textRegex}\\b".r
    val entityFound: Boolean = regex.findFirstIn(text).isDefined

    return entityFound
  }

  /*
   *
  */
  def isRelevant: Boolean = true
}

class Person(text: String) extends NamedEntity(text) {
  def entityType: String = "Person"
}

class Organization(text: String) extends NamedEntity(text) {
  def entityType: String = "Organization"
  override def isRelevant: Boolean = false
}

class University(text: String) extends Organization(text) {
  override def entityType: String = "University"
  override def isRelevant: Boolean = true
}

class Place(text: String) extends NamedEntity(text) {
  def entityType: String = "Place"
  override def isRelevant: Boolean = false
}

class Technology(text: String) extends NamedEntity(text) {
  def entityType: String = "Technology"

  override def matches(text: String): Boolean = {
    val textRegex: String = Pattern.quote(text)
    
    val regex: Regex = s"\\b${textRegex}\\b".r
    val entityFound: Boolean = regex.findFirstIn(text).isDefined

    return entityFound
  }

  override def isRelevant: Boolean = false
}

class ProgrammingLanguage(text: String) extends Technology(text) {
  override def entityType: String = "ProgrammingLanguage"
  override def isRelevant: Boolean = true
}

abstract class Event(text: String) extends NamedEntity(text) {
  
}

class Conferences(text: String) extends Event(text) {
  def entityType: String = "Conferences"
}  
